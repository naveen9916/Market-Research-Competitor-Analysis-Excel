MARKET RESEARCH AND COMPETITOR ANALYSIS USING MICROSOFT EXCEL
===============================================================

IMPORTANT DATA DISCLAIMER
All data and results in this package are simulated for learning and portfolio practice.
They are not actual market research, company-reported sales, verified competitor prices,
or evidence about real-world market leadership. Do not present them as real-world facts.

CONTENTS
--------
01_Raw_Data/
  - Original simulated dataset in Excel and CSV formats.
02_Cleaned_Data/
  - Cleaned/standardized dataset and quality-check summary.
03_Pivot_Tables/
  - Summary tables and KPI calculations. These are calculated summaries, not native PivotTables.
04_Dashboard/
  - KPI dashboard workbook with standard charts and summary sheets.
  - See the user guide for creating native PivotTables, PivotCharts, and slicers in Excel.
05_Final_Report/
  - Final report (.docx) and chart images.
06_Guides/
  - Formula examples workbook.
  - User guide, cleaning steps, PivotTable/slicer steps, interview Q&A.

START HERE
----------
1. Open 01_Raw_Data/Market_Research_Competitor_Analysis_Sample_Dataset.xlsx.
2. Read the Read_Me worksheet.
3. Open 05_Final_Report/Market_Research_Competitor_Analysis_Report.docx.
4. Read 06_Guides/Project_User_Guide_and_Interview_Prep.docx for the build instructions.
5. Use desktop Microsoft Excel for native PivotTables and slicers.

Data layout in Raw_Data:
A Date; B Company Name; C Product Name; D Product Category; E Region;
F Product Price; G Units Sold; H Revenue; I Customer Rating; J Marketing Spend.

Revenue is generated as Product Price × Units Sold.
